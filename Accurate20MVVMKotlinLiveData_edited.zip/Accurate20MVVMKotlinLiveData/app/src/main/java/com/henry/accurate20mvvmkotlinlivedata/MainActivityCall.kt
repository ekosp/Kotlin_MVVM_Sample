package com.henry.accurate20mvvmkotlinlivedata

import android.view.View

interface MainActivityCall {
    fun onCalculate (view: View)
}