package com.henry.accurate20mvvmkotlinlivedata

import android.view.View

interface MainActivityCallbacks {
    fun hitungHarga (view: View)
    fun hitungKembalian (view: View)
}